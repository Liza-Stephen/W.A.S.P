package com.hsbc.db.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.lang.NullPointerException;
import com.hsbc.db.domain.Bug;
import com.hsbc.db.dao.DBUtility;





public class BugDao implements Dao {
	Connection con ;
	Statement stmt;
	String  st;
	public BugDao() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void add (String name,String title,String desc,String date,String severity) {
		
		
			
			try {
				
				 
				st = "select pid from project where pName=" + name;
				con = DBUtility.getConnection();
				
				stmt = con.createStatement();
				PreparedStatement pst = con.prepareStatement("insert into  bugs(title,description,severitylevel,pid) values(?,?,?,?);");
				ResultSet rs = stmt.executeQuery(st);

				if (rs.next()) {
					int id = rs.getInt(1);
					pst.setInt(4,id);
					
				}
				
				
				pst.setString(2, title);
				pst.setString(3, desc);
				
				//pst.setInt(5,testerid);
				Date d2=Date.valueOf(date);
				pst.setDate(6,d2 );
				pst.setString(12, severity);

				pst.executeUpdate();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		


	}
	
}
