package com.hsbc.db.dao;

public interface Dao {

	public void add(String name,String title,String desc,String date,String severity);
}
