package com.hsbc.db.domain;

import java.sql.Date;

public class Bug {

	private int bugid;
	private String title;
	private String description;
	private int pid;
	private int testerid;
	private Date opendate;
	private int assignedto;
	private boolean ismarkedforclosing;
	private int closedby;
	private int closedon;
	private String status;
	private String severitylevel;
	public Bug() {
		super();
		this.bugid = bugid;
		this.title = title;
		this.description = description;
		this.pid = pid;
		this.testerid = testerid;
		this.opendate = opendate;
		this.assignedto = assignedto;
		this.ismarkedforclosing = ismarkedforclosing;
		this.closedby = closedby;
		this.closedon = closedon;
		this.status = status;
		this.severitylevel = severitylevel;
	}
	public int getBugid() {
		return bugid;
	}
	public void setBugid(int bugid) {
		this.bugid = bugid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getTesterid() {
		return testerid;
	}
	public void setTesterid(int testerid) {
		this.testerid = testerid;
	}
	public Date getOpendate() {
		return opendate;
	}
	public void setOpendate(Date opendate) {
		this.opendate = opendate;
	}
	public int getAssignedto() {
		return assignedto;
	}
	public void setAssignedto(int assignedto) {
		this.assignedto = assignedto;
	}
	public boolean isIsmarkedforclosing() {
		return ismarkedforclosing;
	}
	public void setIsmarkedforclosing(boolean ismarkedforclosing) {
		this.ismarkedforclosing = ismarkedforclosing;
	}
	public int getClosedby() {
		return closedby;
	}
	public void setClosedby(int closedby) {
		this.closedby = closedby;
	}
	public int getClosedon() {
		return closedon;
	}
	public void setClosedon(int closedon) {
		this.closedon = closedon;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSeveritylevel() {
		return severitylevel;
	}
	public void setSeveritylevel(String severitylevel) {
		this.severitylevel = severitylevel;
	}
	@Override
	public String toString() {
		return "Bug [bugid=" + bugid + ", title=" + title + ", description=" + description + ", pid=" + pid
				+ ", testerid=" + testerid + ", opendate=" + opendate + ", assignedto=" + assignedto
				+ ", ismarkedforclosing=" + ismarkedforclosing + ", closedby=" + closedby + ", closedon=" + closedon
				+ ", status=" + status + ", severitylevel=" + severitylevel + "]";
	}
	
	
}
