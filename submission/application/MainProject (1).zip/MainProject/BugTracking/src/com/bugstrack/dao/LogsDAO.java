package com.bugstrack.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.derby.impl.sql.execute.AggregatorInfoList;

import com.bugstrack.domain.Logs;
import com.bugstrack.exceptions.UserNotFoundException;
import com.bugstrack.interfaces.LogsInterface;

public class LogsDAO implements LogsInterface {
    private Connection logsDao;
    
	public LogsDAO(Connection logsDao) {
		super();
		this.logsDao = logsDao;
	}

	public void addnewLog(Logs log) {
		// TODO Auto-generated method stub
        String query="insert into logs(logName,description,causedOn,causedByUser) values (?,?,?,?)";
        try {
			PreparedStatement ps=logsDao.prepareStatement(query);
			ps.setString(1, log.getLogName());
			ps.setString(2, log.getDescription());
			Timestamp time=new Timestamp(log.getCausedOn().getTime());
			ps.setTimestamp(3, time);
			ps.setInt(4, log.getCausedByUser());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void addnewLogWithoutUser(Logs log)
	 {
		 String query="insert into logs(logName,description,causedOn) values (?,?,?)";
	        try {
				PreparedStatement ps=logsDao.prepareStatement(query);
				ps.setString(1, log.getLogName());
				ps.setString(2, log.getDescription());
				Timestamp time=new Timestamp(log.getCausedOn().getTime());
				ps.setTimestamp(3, time);
				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 }
	public List<Logs> getlogbyuser(int userId) throws UserNotFoundException {
		// TODO Auto-generated method stub
        String query="select * from logs where causedByUser=?";
        List< Logs> logs=null;
        try {
			PreparedStatement ps=logsDao.prepareStatement(query);
			ps.setInt(1, userId);
			ResultSet rs=ps.executeQuery();
			logs=new ArrayList<Logs>();
			while(rs.next())
			{
				int logId=rs.getInt(1);
				String logName=rs.getString(2);
				String description=rs.getString(3);
				Date causedOn=new Date(rs.getTimestamp(5).getTime());
				logs.add(new Logs(logId, logName, description, userId, causedOn));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		throw new UserNotFoundException("User not found ");
		}
        return logs;
	}

}
