package com.bugstrack.exceptions;

public class RoleDoesNotExistException extends Exception {

	String message;
	
	private static final long serialVersionUID = -5845320650038060602L;
	
	public RoleDoesNotExistException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return  message;
	}

	
}
