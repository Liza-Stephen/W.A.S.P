package com.bugstrack.interfaces;

import com.bugstrack.exceptions.UserAlreadyLoggedInException;
import com.bugstrack.exceptions.UserCannotLoginException;
import com.bugstrack.exceptions.UserCannotLogoutException;
import com.bugstrack.exceptions.UserNotLoggedInException;

public interface UserLoginInterface {
    void userLogin(int userId)throws UserCannotLoginException,UserAlreadyLoggedInException;
    void userLogout(int userId)throws UserNotLoggedInException, UserCannotLogoutException;
    boolean isCurrentlyLoggedIn(int userId);
}
