package com.bugstrack.exceptions;

public class RoleAddException extends Exception {
  String msg;
  int userId;
public RoleAddException(String role,int userId) {
	super();
	this.msg=role;
	this.userId=userId;
}

public String getMsg() {
	return msg;
}
public int getUserId()
{
  return userId;	
}

}
