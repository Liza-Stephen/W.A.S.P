package com.bugstrack.service;

import java.util.Date;
import java.util.regex.Pattern;

import org.json.simple.JSONObject;

import com.bugstrack.domain.Logs;
import com.bugstrack.exceptions.RegisterUserException;
import com.bugstrack.exceptions.UserNotFoundException;
import com.bugstrack.factory.ForwardMethod;
import com.bugstrack.factory.LogsService;
import com.bugstrack.interfaces.UserInterface;

public class RegisterUserService {
	public static boolean validateRole(String role)
	{
		String emailRegex="^[A-Z][a-z]{2,}(?: [A-Z][a-z]*)*$";
		Pattern pat = Pattern.compile(emailRegex); 
		if (role == null) 
		return false; 
		return pat.matcher(role).matches(); 
	}
 public static void registerUser(String emailId,String password,String role)
 {
	UserInterface  users=ForwardMethod.getUserInterface();
	int userId=0;
	try
	{
	userId=users.getUserIdByemail(emailId);
	String userRole=RoleService.getRole(userId);
	if(validateRole(role)&&userRole.equalsIgnoreCase(role))
	users.registerUser(emailId, password);
	}
	catch(UserNotFoundException ex)
	{
		LogsService.addLogWithoutUser(new Logs("UserNotFoundException", ex.getMessage(), new Date()));
	} catch (RegisterUserException e) {
		// TODO Auto-generated catch block
		LogsService.addLog(new Logs("RegisterUserException", e.getMessage(),userId, new Date()));
	}
 }
 public static void  registerUser(JSONObject json)
 {
	 String emailId=(String ) json.get("emailId");
	 String password=(String ) json.get("password");
	 String role=(String ) json.get("role");
	 registerUser(emailId, password, role);
 }
}
