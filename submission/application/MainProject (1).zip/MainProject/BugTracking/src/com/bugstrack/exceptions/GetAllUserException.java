package com.bugstrack.exceptions;

public class GetAllUserException extends Exception {
 String message;

public GetAllUserException(String message) {
	super();
	this.message = message;
}

@Override
public String toString() {
	return message ;
}
 
}
