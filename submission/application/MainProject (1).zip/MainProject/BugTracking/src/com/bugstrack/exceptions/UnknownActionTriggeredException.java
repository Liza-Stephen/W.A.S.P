package com.bugstrack.exceptions;

public class UnknownActionTriggeredException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5082088116729780667L;

	public String message() {
		return "UnknownActionTriggeredException";
	}
	

}
