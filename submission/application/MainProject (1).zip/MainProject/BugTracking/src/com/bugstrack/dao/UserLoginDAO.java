package com.bugstrack.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bugstrack.exceptions.UserAlreadyLoggedInException;
import com.bugstrack.exceptions.UserCannotLoginException;
import com.bugstrack.exceptions.UserCannotLogoutException;
import com.bugstrack.exceptions.UserNotLoggedInException;
import com.bugstrack.interfaces.UserLoginInterface;

public class UserLoginDAO implements UserLoginInterface {
    private Connection userLoginDao;
    
	public UserLoginDAO(Connection userLoginDao) {
		super();
		this.userLoginDao = userLoginDao;
	}

	public void userLogin(int userId) throws UserCannotLoginException, UserAlreadyLoggedInException {
		// TODO Auto-generated method stub
        if(isCurrentlyLoggedIn(userId))
        	throw new UserAlreadyLoggedInException("User Already Logged IN"); // throw exception
        String query="insert into userCurrentLogged values (?)";
        try {
			PreparedStatement ps=userLoginDao.prepareStatement(query);
			ps.setInt(1, userId);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		    throw new UserCannotLoginException();
		}
        
        
	}

	public void userLogout(int userId) throws UserNotLoggedInException, UserCannotLogoutException {
		// TODO Auto-generated method stub
		 if(!isCurrentlyLoggedIn(userId))
			 throw new UserNotLoggedInException(); // throw exception
	        String query="delete from userCurrentLogged values (?)";
	        try {
				PreparedStatement ps=userLoginDao.prepareStatement(query);
				ps.setInt(1, userId);
				ps.executeUpdate();
			} catch (SQLException e) {
			   throw new UserCannotLogoutException("User cannot be logout");
			}
	        
	}

	public boolean isCurrentlyLoggedIn(int userId) {
		// TODO Auto-generated method stub
		boolean res=false;
		String query="select userId from userCurrentLogged where userId= ?";
        try {
			PreparedStatement ps=userLoginDao.prepareStatement(query);
			ps.setInt(1, userId);
			ResultSet rs=ps.executeQuery();
			if(rs.getFetchSize()>0)
				res=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block

		}
		return res;
	}

}
