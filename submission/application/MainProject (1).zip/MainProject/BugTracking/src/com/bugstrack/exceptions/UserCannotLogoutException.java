package com.bugstrack.exceptions;

public class UserCannotLogoutException extends Exception {
	private String message;

	public UserCannotLogoutException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return  message;
	}
	
}
