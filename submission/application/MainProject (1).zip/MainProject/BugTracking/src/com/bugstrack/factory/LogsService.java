package com.bugstrack.factory;

import com.bugstrack.domain.Logs;
import com.bugstrack.interfaces.LogsInterface;

public class LogsService {
public static void addLog(Logs log)
{
	LogsInterface logdao=ForwardMethod.getLogsInterface();
	logdao.addnewLog(log);
}
public static void  addLogWithoutUser(Logs log)
{
	LogsInterface logdao=ForwardMethod.getLogsInterface();
	logdao.addnewLogWithoutUser(log);;
}
}
