package com.bugstrack.exceptions;

public class UserAlreadyLoggedInException extends Exception{

	String message;
	private static final long serialVersionUID = 1373330893613466759L;
	public UserAlreadyLoggedInException(String message) {
		super();
		this.message = message;
	}
	@Override
	public String toString() {
		return  message;
	}

	

}
