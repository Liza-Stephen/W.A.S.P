package com.bugstrack.interfaces;

import java.util.List;

import com.bugstrack.exceptions.UserNotFoundException;
import com.bugstrack.exceptions.RoleAddException;
import com.bugstrack.exceptions.RoleDoesNotExistException;

public interface RolesInterface {
   void addRoles(int userId,String role)throws RoleAddException;
   String getRole(int userId)throws UserNotFoundException;
   List<Integer> getUserByRole(String role)throws RoleDoesNotExistException;
}
