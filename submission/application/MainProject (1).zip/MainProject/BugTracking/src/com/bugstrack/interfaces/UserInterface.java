package com.bugstrack.interfaces;

import java.util.List;

import com.bugstrack.domain.User;
import com.bugstrack.exceptions.GetAllUserException;
import com.bugstrack.exceptions.LastRowFetchException;
import com.bugstrack.exceptions.RegisterUserException;
import com.bugstrack.exceptions.UserAddException;
import com.bugstrack.exceptions.UserNotFoundException;

public interface UserInterface {
   void addUser(User user)throws UserAddException;
   User getUser(int userId)throws UserNotFoundException;
   List<Integer> getAllUser()throws GetAllUserException;
   int lastrowAdded()throws LastRowFetchException;
   void updatePassword(String emailId,String password)throws UserNotFoundException;
   void updateLastLogin(String emailId)throws UserNotFoundException;
   void registerUser(String emailId,String password)throws RegisterUserException, UserNotFoundException;
   int getUserIdByemail(String emailId)throws UserNotFoundException;
   void close();
}
