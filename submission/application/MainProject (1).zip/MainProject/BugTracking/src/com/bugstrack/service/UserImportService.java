package com.bugstrack.service;

import java.util.Date;
import java.util.regex.Pattern;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.bugstrack.domain.Logs;
import com.bugstrack.domain.User;
import com.bugstrack.exceptions.LastRowFetchException;
import com.bugstrack.exceptions.RoleAddException;
import com.bugstrack.exceptions.UserAddException;
import com.bugstrack.factory.ForwardMethod;
import com.bugstrack.factory.LogsService;
import com.bugstrack.interfaces.RolesInterface;
import com.bugstrack.interfaces.UserInterface;

public class UserImportService {
public static boolean validateUser(String userName)
{
	String emailRegex="^[A-Z][a-z]{2,}(?: [A-Z][a-z]*)*$";
	Pattern pat = Pattern.compile(emailRegex); 
	if (userName == null) 
	return false; 
	return pat.matcher(userName).matches(); 
}
public static boolean validateRole(String role)
{
	String emailRegex="^[A-Z][a-z]{2,}(?: [A-Z][a-z]*)*$";
	Pattern pat = Pattern.compile(emailRegex); 
	if (role == null) 
	return false; 
	return pat.matcher(role).matches(); 
}
public static boolean validateEmail(String emailId)
{
	String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
            "[a-zA-Z0-9_+&*-]+)*@" + 
            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
            "A-Z]{2,7}$"; 
              
Pattern pat = Pattern.compile(emailRegex); 
if (emailId == null) 
return false; 
return pat.matcher(emailId).matches(); 
}
public static void addUsers(JSONObject json)
{
	JSONArray array=(JSONArray)json.get("file");
	UserInterface user=ForwardMethod.getUserInterface();
	RolesInterface roles=ForwardMethod.getRoleInterface();
	String userName="",role="",emailId="";
	int userId=0;
	for(Object obj:array)
	{
		try
		{
		userName=(String)((JSONObject)obj).get("userName");
		role=(String)((JSONObject)obj).get("role");
		emailId=(String)((JSONObject)obj).get("emailId");
		if(validateEmail(emailId)&&validateUser(userName)&&validateRole(role))
		{
		user.addUser(new User(userName, emailId));
		userId=user.lastrowAdded();
		roles.addRoles(userId, role); 
		}
		}
		catch(UserAddException ex)
		{
			LogsService.addLogWithoutUser(new Logs("UserAddException", ex.getMessage(), new Date()));
		} catch (RoleAddException e) {
			// TODO Auto-generated catch block
			LogsService.addLog(new Logs("RoleAddException", e.getMessage(), userId, new Date()));
			
		} catch (LastRowFetchException e) {
			// TODO Auto-generated catch block
			LogsService.addLogWithoutUser(new Logs("LastRowFetchException", e.getMessage(), new Date()));
		}
	}
}
}
