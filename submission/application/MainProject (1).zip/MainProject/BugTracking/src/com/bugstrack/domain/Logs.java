package com.bugstrack.domain;

import java.util.Date;

public class Logs {
	private int logId;
	private String logName;
	private String description;
	private int causedByUser;
	private Date causedOn;
	
	public Logs(int logId, String logName, String description, int causedByUser,Date causedOn) {
		super();
		this.logId = logId;
		this.logName = logName;
		this.description = description;
		this.causedByUser = causedByUser;
		this.causedOn=causedOn;
	}
	public Logs(String logName, String description, int causedByUser,Date causedOn) {
		super();
		this.logName = logName;
		this.description = description;
		this.causedByUser = causedByUser;
		this.causedOn=causedOn;
	}
	public Logs(String logName, String description,Date causedOn) {
		super();
		this.logName = logName;
		this.description = description;
		this.causedByUser = 0;
		this.causedOn=causedOn;
	}
	public int getLogId() {
		return logId;
	}
	public void setLogId(int logId) {
		this.logId = logId;
	}
	public String getLogName() {
		return logName;
	}
	public void setLogName(String logName) {
		this.logName = logName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getCausedByUser() {
		return causedByUser;
	}
	public void setCausedByUser(int causedByUser) {
		this.causedByUser = causedByUser;
	}
	
	public Date getCausedOn() {
		return causedOn;
	}
	public void setCausedOn(Date causedOn) {
		this.causedOn = causedOn;
	}
	@Override
	public String toString() {
		return "Logs [logId=" + logId + ", logName=" + logName + ", description=" + description + ", causedByUser="
				+ causedByUser + ", causedOn=" + causedOn + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + logId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Logs other = (Logs) obj;
		if (logId != other.logId)
			return false;
		return true;
	}
	
}
