package com.bugstrack.service;

import java.util.Date;

import org.json.simple.JSONObject;

import com.bugstrack.domain.Logs;
import com.bugstrack.domain.User;
import com.bugstrack.exceptions.UserAlreadyLoggedInException;
import com.bugstrack.exceptions.UserCannotLoginException;
import com.bugstrack.exceptions.UserCannotLogoutException;
import com.bugstrack.exceptions.UserNotFoundException;
import com.bugstrack.exceptions.UserNotLoggedInException;
import com.bugstrack.factory.ForwardMethod;
import com.bugstrack.factory.LogsService;
import com.bugstrack.interfaces.UserInterface;
import com.bugstrack.interfaces.UserLoginInterface;

public class LoginUserService {
  public static JSONObject performLogin(JSONObject json)
  {
	  String emailId=(String) json.get("emailId");
	  String password=(String )json.get("password");
	  return performLogin(emailId,password);
  }
  public static JSONObject performLogin(String emailId,String password)
  {
	  UserInterface userdao=ForwardMethod.getUserInterface();
	  int userId=0;
	  JSONObject json=new JSONObject();
	try {
		userId = userdao.getUserIdByemail(emailId);
		 User user=userdao.getUser(userId);
		  if(user.getPassword().equalsIgnoreCase(password))
		  {
			  UserLoginInterface login=ForwardMethod.getUserLoginInterface();
			  if(!login.isCurrentlyLoggedIn(userId))
			  {
				  login.userLogin(userId);
				  json.put("message", "success");
				  json.put("userId", userId);
				  json.put("role", RoleService.getRole(userId));
				  json.put("userName", user.getUserName());
				  json.put("emailId", emailId);
			  }
		  }
	} catch (UserNotFoundException e) {
		// TODO Auto-generated catch block
		json.put("message", "failed");
		LogsService.addLogWithoutUser(new Logs("UserNotFoundException", e.getMessage(), new Date()));
	} catch (UserAlreadyLoggedInException e) {
		// TODO Auto-generated catch block
		json.put("message", "failed");
		LogsService.addLog(new Logs("UserAlreadyLoggedInException", e.getMessage(), userId, new Date()));
	} catch (UserCannotLoginException e) {
		// TODO Auto-generated catch block
		json.put("message", "failed");
		LogsService.addLogWithoutUser(new Logs("UserCannotLoginException", e.getMessage(), new Date()));
	}
	 return json;
	  
  }
  public static JSONObject performLogout(int userId)
  {
	  UserLoginInterface login=ForwardMethod.getUserLoginInterface();
	  JSONObject json=new JSONObject();
	  try
	  {
	  if(login.isCurrentlyLoggedIn(userId))
	  {
		  login.userLogout(userId);
		  json.put("message", "success");
	  }
	  }
	  catch(UserNotLoggedInException ex)
	  {
		  json.put("message", "failed");
		  LogsService.addLog(new Logs("UserNotLoggedInException", ex.getMessage(), userId, new Date()));
		  
	  } catch (UserCannotLogoutException e) {
		// TODO Auto-generated catch block
		json.put("message", "failed");
		LogsService.addLog(new Logs("UserCannotLoginException", e.getMessage(), userId, new Date()));
	}
	  return json;
  }
}
