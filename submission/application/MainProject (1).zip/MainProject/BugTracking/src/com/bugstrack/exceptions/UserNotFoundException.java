package com.bugstrack.exceptions;

public class UserNotFoundException extends Exception{

	String message;
	
	public UserNotFoundException(String msg) {
		super();
		this.message = msg;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return message ;
	}
	

}
