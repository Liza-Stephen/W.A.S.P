package com.bugstrack.exceptions;

public class ProjectDoesNotExistExeption extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1742463417264010309L;
	
	public String message() {
		return "ProjectDoesNotExistExeption";
	}


}
