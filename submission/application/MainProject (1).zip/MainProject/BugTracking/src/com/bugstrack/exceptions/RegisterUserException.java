package com.bugstrack.exceptions;

public class RegisterUserException extends Exception {
     String message;

	public RegisterUserException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return message ;
	}
     
}
