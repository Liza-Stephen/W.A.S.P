package com.bugstrack.exceptions;

public class UserAddException extends Exception {
    String message;

	public UserAddException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return  message;
	}
    
}
