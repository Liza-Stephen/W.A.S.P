package com.bugstrack.exceptions;

public class LastRowFetchException extends Exception {
  String message;

public LastRowFetchException(String message) {
	super();
	this.message = message;
}

public String getMessage() {
	return message;
}

@Override
public String toString() {
	return  message;
}
  
}
