package com.bugstrack.interfaces;

import java.util.List;

import com.bugstrack.domain.Logs;
import com.bugstrack.exceptions.UserNotFoundException;

public interface LogsInterface {
   void addnewLog(Logs log);
   void addnewLogWithoutUser(Logs log);

   List<Logs> getlogbyuser(int userId)throws UserNotFoundException;
}
