package com.hsbc.db.dao;


import com.hsbc.db.exceptions.BugNotFoundException;
import com.hsbc.db.exceptions.NotMarkedClosedException;
import com.hsbc.db.exceptions.ProjectCannotBeAddedException;
import com.hsbc.db.exceptions.ProjectCompletedException;
import com.hsbc.db.exceptions.ProjectNotFoundException;

public interface Dao {

	void add(String name,String title,String desc,String date,String severity,int testerid) throws ProjectNotFoundException, ProjectCompletedException, ProjectCannotBeAddedException;
	void markForClosing(int id) throws BugNotFoundException;
	void closeBug(int id, String date, int closedby) throws NotMarkedClosedException;
}
