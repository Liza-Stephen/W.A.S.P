package com.hsbc.db.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.hsbc.db.exceptions.BugNotFoundException;
import com.hsbc.db.exceptions.NotMarkedClosedException;
import com.hsbc.db.exceptions.ProjectCannotBeAddedException;
import com.hsbc.db.exceptions.ProjectCompletedException;
import com.hsbc.db.exceptions.ProjectNotFoundException;

public class BugDao implements Dao {
	Connection con;
	public BugDao() {
		super();
	}

	public void add (String name,String title,String desc,String date,String severity,int testerid) throws ProjectNotFoundException, ProjectCompletedException, ProjectCannotBeAddedException {
		try {			
			con = DBUtility.getConnection();
			PreparedStatement pst1 = con.prepareStatement("select * from project where pname=?");
			pst1.setString(1, name);
			ResultSet rs = pst1.executeQuery();
			
			if (rs.next()) {
				int id = rs.getInt(1);
				String status = rs.getString(5);
				String str = "In-progress";					
				if(status.equals(str)) {
					PreparedStatement pst = con.prepareStatement("insert into  bugs(title,description,severitylevel,pid,opendate,testerid) values(?,?,?,?,?,?);");
					pst.setString(1, title);
					pst.setString(2, desc);
					pst.setString(3, severity);
					pst.setInt(4,id);
					Date opendate=Date.valueOf(date);
					pst.setDate(5,opendate );
					pst.setInt(6,testerid);
					pst.executeUpdate();
				}
				else
					throw new ProjectCompletedException();				
			}
			else
				throw new ProjectNotFoundException();			
		} 
		catch (SQLException e1) {
			throw new ProjectCannotBeAddedException();	
		}
}

	@Override
	public void markForClosing(int id) throws BugNotFoundException {
		try {
			con = DBUtility.getConnection();
			PreparedStatement pst = con.prepareStatement("select * from bugs where bugid=?");
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();			
			if (rs.next()) {
				String query = "update bugs set ismarkedforclosing=? where bugid=?";
				PreparedStatement pst1 = con.prepareStatement(query);
				pst1.setBoolean(1, true);
				pst1.setInt(2, id);
				pst.executeUpdate();
			}
			else
				throw new BugNotFoundException();		
		}
		catch (SQLException e1) {
			throw new BugNotFoundException();
		}		
	}

	@Override
	public void closeBug(int id, String date,int closedby) throws NotMarkedClosedException {
		try {
			String query = "select ismarkedforclosing from bugs where bugid=?";
			String query1= "update bugs set closedon=?,closedby=? where bugid=?";
			con = DBUtility.getConnection();
			
			PreparedStatement pst1=con.prepareStatement(query);
			pst1.setInt(1,id);
			ResultSet rs = pst1.executeQuery();
			if (rs.next()) {
				boolean condition = rs.getBoolean(8);
				if(condition) {
					PreparedStatement pst=con.prepareStatement(query1);
					Date closedon=Date.valueOf(date);
					pst.setDate(1,closedon );
					pst.setInt(2,closedby);
					pst.setInt(3,id);
					pst.executeUpdate();
				}
				else
					throw new NotMarkedClosedException();
			}
		}
		catch (SQLException e1) {
			throw new NotMarkedClosedException();
		}
	}	
}
		
		
	
	

