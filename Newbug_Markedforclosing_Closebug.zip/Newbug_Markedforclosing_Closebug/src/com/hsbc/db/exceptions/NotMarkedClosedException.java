package com.hsbc.db.exceptions;

public class NotMarkedClosedException extends Exception {

	public NotMarkedClosedException() {
		super();
	}
	public String showMessage() {
		return "Bug Not Marked for Closing by developer!";
	}
}
