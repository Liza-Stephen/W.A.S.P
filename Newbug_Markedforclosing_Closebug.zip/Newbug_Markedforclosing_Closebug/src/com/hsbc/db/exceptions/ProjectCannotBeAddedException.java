package com.hsbc.db.exceptions;

public class ProjectCannotBeAddedException extends Exception{

	public ProjectCannotBeAddedException() {
		super();
	}
	public String showMessage() {
		return "Project Cannot be Added!";
	}
}