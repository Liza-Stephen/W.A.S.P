package com.bugstrack.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bugstrack.interfaces.UserLoginInterface;

public class UserLoginDAO implements UserLoginInterface {
    private Connection userLoginDao;
    
	public UserLoginDAO(Connection userLoginDao) {
		super();
		this.userLoginDao = userLoginDao;
	}

	public void userLogin(int userId) {
		// TODO Auto-generated method stub
        if(isCurrentlyLoggedIn(userId))
        	return; // throw exception
        String query="insert into userCurrentLogged values (?)";
        try {
			PreparedStatement ps=userLoginDao.prepareStatement(query);
			ps.setInt(1, userId);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
	}

	public void userLogout(int userId) {
		// TODO Auto-generated method stub
		 if(isCurrentlyLoggedIn(userId))
	        	return; // throw exception
	        String query="delete from userCurrentLogged values (?)";
	        try {
				PreparedStatement ps=userLoginDao.prepareStatement(query);
				ps.setInt(1, userId);
				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	}

	public boolean isCurrentlyLoggedIn(int userId) {
		// TODO Auto-generated method stub
		boolean res=false;
		String query="select userId from userCurrentLogged where userId= ?";
        try {
			PreparedStatement ps=userLoginDao.prepareStatement(query);
			ps.setInt(1, userId);
			ResultSet rs=ps.executeQuery();
			if(rs.getFetchSize()>0)
				res=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

}
