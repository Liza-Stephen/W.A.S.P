package com.bugstrack.factory;

import java.awt.image.BufferedImage;
import java.sql.Connection;

import com.bugstrack.dao.BugDAO;
import com.bugstrack.dao.ProjectDAO;
import com.bugstrack.dao.RolesDAO;
import com.bugstrack.dao.TeamDAO;
import com.bugstrack.dao.UserDAO;
import com.bugstrack.dao.UserLoginDAO;
import com.bugstrack.db.DatabaseConnection;
import com.bugstrack.interfaces.BugInterface;
import com.bugstrack.interfaces.ProjectInterface;
import com.bugstrack.interfaces.RolesInterface;
import com.bugstrack.interfaces.TeamInterface;
import com.bugstrack.interfaces.UserInterface;
import com.bugstrack.interfaces.UserLoginInterface;

public class ForwardMethod {
  public static Connection conn=DatabaseConnection.getConnection();
  
  public static ProjectInterface getProjectInterface()
  {
	  return new ProjectDAO(conn);
  }
  public static TeamInterface getTeamInterface()
  {
	  return new TeamDAO(conn);
  }
  public static UserInterface getUserInterface()
  {
	  return new UserDAO(conn);
  }
  public static BugInterface getBugInterface() {
	return new BugDAO(conn);
   }
  public static RolesInterface getRoleInterface()
  {
	  return new RolesDAO(conn);
  }
  public static UserLoginInterface getUserLoginInterface()
  {
	  return new UserLoginDAO(conn);
  }
  public static void close()
  {
	  conn=null;
	  DatabaseConnection.close();
  }
}
