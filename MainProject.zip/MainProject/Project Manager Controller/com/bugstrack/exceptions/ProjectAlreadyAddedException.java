package com.bugstrack.exceptions;

public class ProjectAlreadyAddedException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3747236127515247822L;
	public String message() {
		return "ProjectAlreadyAddedException";
	}


}
