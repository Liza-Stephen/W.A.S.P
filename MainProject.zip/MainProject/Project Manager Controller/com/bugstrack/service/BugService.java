package com.bugstrack.service;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.bugstrack.dao.BugDAO;
import com.bugstrack.dao.ProjectDAO;
import com.bugstrack.domain.Bug;
import com.bugstrack.domain.Project;
import com.bugstrack.factory.ForwardMethod;
import com.bugstrack.interfaces.BugInterface;
import com.bugstrack.interfaces.ProjectInterface;
import com.bugstrack.interfaces.TeamInterface;

public class BugService {
	 public static List<Bug> getBugSortable(int userId)
	    {
	    	List<Integer> pids=TeamService.getProjectIds(userId);
	    	List<Bug> bugs=new ArrayList<Bug>();
	    	BugInterface bugDao=ForwardMethod.getBugInterface();
	    	ProjectInterface pr=ForwardMethod.getProjectInterface();
	    	for(int pid:pids)
	    	{
	    		if(pr.getStatus(pid).equalsIgnoreCase("open"))
	    		bugs.addAll(bugDao.getBugs(pid));
	    	}
	    	Collections.sort(bugs);
	    	return bugs;
	    }
	 public static List<Bug> getBugSortableByManager(int userId)
	    {
	    	List<Integer> pids=ProjectService.getProjectIdByManager(userId);
	    	List<Bug> bugs=new ArrayList<Bug>();
	    	BugInterface bugDao=ForwardMethod.getBugInterface();
	    	ProjectInterface pr=ForwardMethod.getProjectInterface();
	    	for(int pid:pids)
	    	{
	    		if(pr.getStatus(pid).equalsIgnoreCase("inprogress"))
	    		bugs.addAll(bugDao.getBugs(pid));
	    	}
	    	Collections.sort(bugs);
	    	return bugs;
	    }
	 public static List<Integer> getProjectsIdByUser(int userId)
	    {
	    	TeamInterface team=ForwardMethod.getTeamInterface();
	    	List<Integer> pids=team.getProjects(userId);
	    	return pids;
	    }
	 public static String sendBugSortable(int userId)
	 {
		 List<Bug> bugs=getBugSortable(userId);
		 JSONArray array=new JSONArray();
		 JSONArray temp=null;
		 JSONObject obj=null;
		 for(Bug b:bugs)
		 {
			 obj=new JSONObject();
			 obj.put("decription", b.getDescription());
			 obj.put("title", b.getTitle());
			 obj.put("openDate", b.getOpenDate().toString());
			 List<Integer> list=TeamService.getTeamMembers(b.getBugId());
			 temp=new JSONArray();
			 for(int user:list)
			 {
				 if(RoleService.getRole(user).equalsIgnoreCase("developer"))
					 temp.add(ForwardMethod.getUserInterface().getUser(user).getUserName());
			 }
			 obj.put("developers", temp);
			 array.add(obj);
		 }
	    	return array.toJSONString();
	 }

	 public static void addnewBug(JSONObject json,int userId)
	 {
		 String pName=(String )json.get("pName");
		 String title=(String)json.get("title");
		 String description=(String )json.get("description");
		 String severityLevel=(String)json.get("severityLevel");
		 addnewBug(pName, title, description, severityLevel, userId);
	 }
	 public static void addnewBug(String pName,String title,String description,String severityLevel,int userId)
	 {
		 int pid=ForwardMethod.getProjectInterface().getProjectId(pName);
		 Bug bug=new Bug(title, description, pid, userId, new Date(), "open", severityLevel);
		 BugInterface bugAdd=ForwardMethod.getBugInterface();
		 bugAdd.add(bug);
	 }
}
