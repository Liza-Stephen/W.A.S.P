package com.bugstrack.service;

import org.json.simple.JSONObject;

import com.bugstrack.domain.User;
import com.bugstrack.factory.ForwardMethod;
import com.bugstrack.interfaces.UserInterface;
import com.bugstrack.interfaces.UserLoginInterface;

public class LoginUserService {
  public static void performLogin(JSONObject json)
  {
	  String emailId=(String) json.get("emailId");
	  String password=(String )json.get("password");
	  performLogin(emailId,password);
  }
  public static void performLogin(String emailId,String password)
  {
	  UserInterface userdao=ForwardMethod.getUserInterface();
	  int userId=userdao.getUserIdByemail(emailId);
	  User user=userdao.getUser(userId);
	  if(user.getPassword().equalsIgnoreCase(password))
	  {
		  UserLoginInterface login=ForwardMethod.getUserLoginInterface();
		  if(!login.isCurrentlyLoggedIn(userId))
		  {
			  login.userLogin(userId);
		  }
	  }
	  
  }
  public static void performLogout(int userId)
  {
	  UserLoginInterface login=ForwardMethod.getUserLoginInterface();
	  if(login.isCurrentlyLoggedIn(userId))
	  {
		  login.userLogout(userId);
	  }
  }
}
