package com.bugstrack.interfaces;

public interface UserLoginInterface {
    void userLogin(int userId);
    void userLogout(int userId);
    boolean isCurrentlyLoggedIn(int userId);
}
